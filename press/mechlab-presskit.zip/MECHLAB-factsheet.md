# MECHLAB press kit

## Factsheet

| | |
|---|---|
| **Title** | MECHLAB |
| **Developer** | Schreyer Data & Automation LLC |
| **Based in** | Mankato, Minnesota, USA |
| **Platform** | Meta Quest 3 and Quest 3S (Meta Horizon Store) |
| **Release** | Free playable demo: coming soon (date to be announced). Full game: Q1 2027 (Coming Soon, wishlist now) |
| **Price** | Demo: free. Full game: TBA |
| **Genre** | VR mech battler: build, launch, fight |
| **Players** | Single-player; online 1v1 (full game) |
| **Play style** | Stationary, seated or standing; Touch controllers |
| **Comfort** | Comfortable (the viewpoint never moves) |
| **Languages** | English |
| **Build** | 0.41.x |
| **Store pages** | Full game: https://www.meta.com/experiences/mechlab/1429033505408598/ · Demo: coming soon |
| **Website** | https://collin-schreyer.github.io/mechlab-site |
| **Press contact** | collin.schreyer@gmail.com |
| **Socials** |  ·  ·  |

## One-liner

Build a toy-sized battle mech with your own hands, fire it into the arena from a capsule cannon, and fight from ringside.

## Short description (50 words)

MECHLAB is a VR robot battler for Meta Quest. Snap together a toy-sized mech on a physical workbench, aim a first-person capsule cannon to launch it into the arena, then fight from ringside with a fighting-game HUD, a live stadium big screen and a killer's-eye kill cam after every K.O.

## Description

MECHLAB is about the joy of building something small and watching it fight big.

It starts on a workbench. You pick parts off a tabletop deck with your own hands (guns, bombs, homing pods, legs and bodies) and snap them onto a toy-sized mech on a turntable. A stats tablet updates as you build, and the mech itself reacts to every new part: it looks at its new arm cannon, tests its new legs and blinks at you.

Then you launch it. Every round starts at a first-person capsule cannon: you aim at a landing spot in the arena, fire, and your mech bursts out of the capsule ready to fight.

The fights happen in front of you, from ringside. You drive your mech from the rail with a fighting-game HUD while a stadium big screen broadcasts the match. In the VS intro your mech stands on a pedestal and mirrors your real head and arm movements. After every K.O., the big screen rewinds and plays a killer's-eye kill cam.

MECHLAB is a toy-robot battler built for VR, where the part you hold in your hand is the part you fight with.

## Features

- **Build it by hand.** 30+ parts across guns, bombs, pods, legs and bodies, snapped on at a physical workbench. The mech reacts to every change.
- **Launch it.** Aim a first-person capsule cannon and fire your mech into the arena.
- **Fight from ringside.** A fighting-game HUD, a live big screen, VS intros where your mech mirrors you, and a kill cam after every K.O. Best of three.
- **Quick Battle.** Random builds, any arena, 1v1 up to 3v3 and 1v4 team battles with right-stick lock-on.
- **Rival Ladder.** SPARKY, BOLT, HALO, VIPER and the illegal champion KING CROWN.
- **Online 1v1.** LAN now, internet rooms coming.
- **Story chapter.** The Haven district, a sewer and pipe infiltration, a security test-pit 2v2 and an EDEN 1v3 ambush.
- **Six arenas.**
  - Skyline Training Deck
  - Haven Freight Yard
  - EDEN Foundry (pits)
  - Hardlight Cube (holographic)
  - Assembly Line (conveyors, presses and shredders)
  - Reactor Core (laser sweepers, vents and overload switches)
- **Comfortable.** A stationary viewpoint, playable seated or standing.

## What's in the free demo

- The opening of the story: the friendly match with Dex, then a sponsor's exhibition that goes strangely wrong (about 30 minutes)
- Quick Battle in three arenas (Skyline Training Deck, Hardlight Cube, Assembly Line), 1v1 and 2v2
- The first two ladder rivals, SPARKY and BOLT
- The workbench garage with a starter set of 16 parts

## Team

MECHLAB is made by Schreyer Data & Automation, a one-person studio in Mankato, Minnesota (design, code and art)

## Assets

- **Screenshots:** 2560×1440 PNG (`screenshots/`)
- **Key art:**
  - landscape, square and portrait
  - hero banner
  - logo on a transparent background
  - app icon
- **Trailer:** 1080p MP4 (`trailer/`)

All of the above is in the downloadable zip on the press page: `mechlab-presskit.zip`.

You may use these assets in coverage of MECHLAB.

## Legal

MECHLAB © 2026 Schreyer Data & Automation LLC. Meta Quest is a trademark of Meta Platforms, Inc.

## AI disclosure

MECHLAB uses AI-generated content: 3D models (Meshy); voices, sound effects and music (ElevenLabs); some 2D art (OpenAI). Code was written with AI assistants.

## Contact

Press, keys and interviews: collin.schreyer@gmail.com
